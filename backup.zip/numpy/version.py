
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.14.0'
version = '1.14.0'
full_version = '1.14.0'
git_revision = '6914bb41f0fb3c1ba500bae4e7d671da9536786f'
release = True

if not release:
    version = full_version
